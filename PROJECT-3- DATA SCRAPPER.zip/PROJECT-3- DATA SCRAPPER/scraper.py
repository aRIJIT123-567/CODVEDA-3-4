import requests
from bs4 import BeautifulSoup
import csv
import tkinter as tk
from tkinter import messagebox

def scrape_data():
    url = entry.get()

    headers = {
        "User-Agent":"Mozilla/5.0"
    }

    try:
        response = requests.get(url,headers=headers,verify=False)

        soup = BeautifulSoup(response.text,"html.parser")

        titles = soup.find_all("h2")

        output.delete(1.0,tk.END)

        with open("scraped_data.csv","w",newline='',encoding='utf-8') as file:

            writer = csv.writer(file)
            writer.writerow(["Titles"])

            for t in titles:
                text = t.text.strip()
                writer.writerow([text])
                output.insert(tk.END,text+"\n")

        messagebox.showinfo("Success","Data Scraped Successfully")

    except:
        messagebox.showerror("Error","Invalid URL")

# GUI window
root = tk.Tk()
root.title("Data Scraper Prototype")
root.geometry("500x400")

tk.Label(root,text="Enter Website URL").pack()

entry = tk.Entry(root,width=50)
entry.pack()

tk.Button(root,text="Scrape Data",command=scrape_data).pack()

output = tk.Text(root,height=15,width=60)
output.pack()

root.mainloop()