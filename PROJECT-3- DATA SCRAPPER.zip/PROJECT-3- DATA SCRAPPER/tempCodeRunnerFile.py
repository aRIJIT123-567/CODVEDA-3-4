import requests
from bs4 import BeautifulSoup
import csv

# Website URL (example news website)
url = "https://example.com"

# Send request to website
response = requests.get(url)

# Parse HTML content
soup = BeautifulSoup(response.text, "html.parser")

# Extract data (example: all headings)
headlines = soup.find_all("h2")

# Open CSV file
with open("scraped_data.csv", "w", newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    
    # Write header
    writer.writerow(["Headlines"])
    
    # Write data
    for headline in headlines:
        writer.writerow([headline.text.strip()])

print("Data scraped and saved to CSV successfully!")