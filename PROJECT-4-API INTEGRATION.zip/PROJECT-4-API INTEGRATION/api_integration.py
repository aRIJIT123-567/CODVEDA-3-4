# Task 3: API Integration Prototype
# Name: Arijit Kumar Mohanty
# Internship: Codeveda Technologies

import requests
import tkinter as tk
from tkinter import messagebox
import urllib3

urllib3.disable_warnings()

def fetch_data():

    url = "https://official-joke-api.appspot.com/random_joke"

    try:
        response = requests.get(url, verify=False)

        if response.status_code == 200:

            data = response.json()

            output.delete(1.0, tk.END)

            output.insert(tk.END,"API DATA FETCHED\n\n")

            output.insert(tk.END,"Joke:\n")
            output.insert(tk.END,data['setup']+"\n\n")

            output.insert(tk.END,"Answer:\n")
            output.insert(tk.END,data['punchline'])

        else:
            messagebox.showerror("Error","Failed API Request")

    except:
        messagebox.showerror("Error","Connection Failed")


# GUI Design
root = tk.Tk()
root.title("API Integration Prototype")
root.geometry("500x350")

title = tk.Label(root,text="API Integration App",
                 font=("Arial",16,"bold"))
title.pack(pady=10)

btn = tk.Button(root,text="Fetch API Data",
                command=fetch_data,
                bg="lightblue")
btn.pack(pady=10)

output = tk.Text(root,height=12,width=55)
output.pack()

root.mainloop()