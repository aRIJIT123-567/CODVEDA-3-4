import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

url = "https://api.coindesk.com/v1/bpi/currentprice.json"

try:
    print("Fetching API data...")

    response = requests.get(url, verify=False)

    if response.status_code == 200:

        data = response.json()

        print("API Data Retrieved Successfully")

        print("Updated Time:",data['time']['updated'])

        print("Bitcoin Price USD:",
              data['bpi']['USD']['rate'])

        print("Bitcoin Price GBP:",
              data['bpi']['GBP']['rate'])

    else:
        print("API request failed")

except Exception as e:
    print("Error:", e)